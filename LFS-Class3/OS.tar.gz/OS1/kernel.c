int kmain(){
	char* vidmem=(char*)0xb8000;
	vidmem[0] = 'Y';
	vidmem[1] = 0x09;
	vidmem[2] = 'E';
	vidmem[3] = 0x09;
}
