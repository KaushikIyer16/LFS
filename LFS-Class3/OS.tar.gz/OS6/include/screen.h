#ifndef SCREEN_H
#define SCREEN_H
#include "system.h"
#include "string.h"
int cursorX , cursorY;
const uint8 sw ,sh ,sd ; 
                                                    //We define the screen width, height, and depth.
void clearLine(uint8 from,uint8 to);

void updateCursor();

void clearScreen();

void scrollUp(uint8 lineNumber);

void newLineCheck();

void printch(char c);

void print (string ch);
void set_screen_colour_from_colour_code(int colour_code);
void set_screen_colour(int text_colour,int bg_colour);
void print_coloured(string ch,int text_colour,int bg_colour);


#endif
