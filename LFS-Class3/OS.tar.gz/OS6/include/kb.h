#ifndef KB_H
#define KB_H
#include "screen.h"
#include "util.h"

string readStr();

#endif
