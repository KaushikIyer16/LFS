#include "include/screen.h"
int16 kmain()
{       
        clearScreen();
        print("Hi, You just built your first OS");
}
