nasm -f elf32 kernel.asm -o kasm.o
gcc -m32 -c kernel.c -o kc.o
ld -m elf_i386 -T link.ld -o LFS-OS/boot/kernel.bin kasm.o kc.o 
qemu-system-i386 -kernel LFS-OS/boot/kernel.bin
grub-mkrescue -o lfs-os.iso LFS-OS/

read a


