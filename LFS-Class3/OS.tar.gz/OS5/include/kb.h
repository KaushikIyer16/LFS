#ifndef KB_H
#define KB_H
#include "screen.h"

string readStr();

#endif
