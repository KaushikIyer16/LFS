#include "include/kb.h"
#include "include/isr.h"
#include "include/idt.h"
kmain()
{
       isr_install();
       clearScreen();
       
       print("Hi and Welcome to LFS operating system\nPlease enter a command");
       printch('\n');
       print("LFS-OS> ");
       while (1)
       {
                string ch = readStr();
                print("\n");
                print(ch);
               /* if(strEql(ch,"cmd"))
                {
                        print("\nYou are allready in cmd\n");
                }
                else if(strEql(ch,"clear"))
                {
                        clearScreen();
                        print("LFS-OS> ");
                }
                
                else
                {
                        print("Bad command!");
                } */       
       }
        
}
